# MockTIA Standardized Labs — November 11, 2026

This ZIP contains a complete copy of your MockTIA repository with a consistent branded top header added to 56 lab HTML pages. All original JavaScript, onclick handlers, links and element IDs were preserved as text; the original learning activities and scores were not rewritten.

What was updated:
- Unified neon chip logo / MockTIA Labs identity in the lab headers
- Consistent header sizing, spacing and responsive styling
- Matching widths where the existing `mocktiaAssessment` section is present

Important limitations:
- This is a layout-only pass, not an end-to-end browser test or verified scoring upgrade.
- Many labs use differing existing assessment implementations, so the audit reports 'not identified' for most pages.
- `labs/MockTIA_4_1_2_Find_BIOS_UEFI_Settings.html` is only 1 byte in the uploaded repository. It was preserved unchanged and needs the original full lab restored.
- Home/index pages were left unchanged. A few pages without a header received one.

How to publish:
1. Keep your original GitHub repository ZIP as a backup.
2. Extract this ZIP. Open the `MockTIA-main` folder inside.
3. Test several of the updated HTML labs locally, especially mode toggles, reset, scoring, images and printing.
4. Upload the contents of `MockTIA-main` into the matching paths in GitHub's `main` branch, not the outer ZIP or an extra `MockTIA-main` folder. Existing matching paths must be replaced. You may find a desktop Git client easiest for bulk updates.
5. Wait for GitHub Pages deployment and test the live site.

See `MOCKTIA_LAYOUT_AUDIT.csv` for a per-page summary. It is a quality-check file, not required for the website.
